function initMap() {
    const map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 0, lng: 0 },
        zoom: 10,
    });

    function updateDeliveryLocation() {

        const deliveryLocation = { lat: 1, lng: 1 };

        const deliveryMarker = new google.maps.Marker({
            position: deliveryLocation,
            map: map,
            title: 'Delivery Location',
        });

        map.setCenter(deliveryLocation);
    }

    setInterval(updateDeliveryLocation, 10000);
}

document.write('<script async defer src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&callback=initMap"><\/script>');
