<?php
$servername="localhost";
$username="root";
$password="";
$dbname="forgetpassword";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn)
{
    echo"connected";
    else{
        echo"not connected";
    } 
    is(isset($enterphonenumber)||isset($enternewpassword)||isset($confirmnewpassword))
    {
        $enterphonenumber=$_POST['enterphonenumber'];
        $enternewpassword=$_POST['enternewpassword'];
        $confirmnewpassword=$_POST['enternewpassword'];
        $sql="INSERT INTO `resetpassword`(`enterphonenumber`,`enternewpassword`,'confirmnewpassword)VALUES(`$enterphonenumber`,`$enternewpassword`,'$confirmnewpassword)";
        $result=mysqli_query($conn,$sql);
        if($result)
        {
            echo"password changed successful";
        }
        else
        {
            echo"password change failed......!";
        }
    }
}
?>