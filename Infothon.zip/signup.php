<?php
$servername="localhost";
$name=$_POST['fullname'];
$phonenumber=$_POST['phonenumber'];
$pass=$_POST['password'];
$db="signup";
$conn= mysqli_connect('localhost','root','','','test');
if($conn->connect_error){
    die('connection Failed:'$conn->connect_error);
}
else{
    $stmt=$conn->prepare("insert into signup (name,phonenumber,password) values(?,?,?)");
    $stmt->blind_param("sis",$name,$phonenumber,$password);
    $stmt->execute();
    echo "Login sucessfully...";
    $stmt->close();
    $stmt->conn();
}
?>
